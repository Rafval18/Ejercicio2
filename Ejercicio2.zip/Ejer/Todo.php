<?php
    require_once("autoload.php");

    class Todo{
        public $conn;
        public $workers=[];
	

        function __construct()
        {
            $file = file_get_contents(__DIR__ . "/config/db.json");;
            $archivo=json_decode($file, true);
            try {
                $this->conn = new PDO("mysql:host={$archivo['host']};
                dbname={$archivo['dbname']};",
                $archivo["user"],
                $archivo["password"]);
                $this->conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
                //print_r($this->conn);    
            } catch (PDOException $th) {
                echo "No funciona, no se conecta".$th->getMessage();
            }
        }
    
        function getWorkers(){
            return $this->workers;
        }
        function setWorkers($workers){
            $this->workers=$workers;
        }


        function getAll(){
            try {
                $sql="SELECT * FROM worker";
                $stmt=$this->conn->query($sql);
                $workers=[];
                $result=$stmt->fetchAll(PDO::FETCH_ASSOC);
                //print_r($result); exit;
                foreach ($result as $key => $worker) {
                    /* print_r($worker);
                    echo "<br>"; */
                    array_push($workers, new Worker(
                        $worker["ID"],
                        $worker["NAME"],
                        $worker["EMAIL"],
                        $worker["COUNTRY"],
                        $worker["ABOUT"],
                        /* $worker["LANGUAGE"],
                        $worker["SKILLS"], */
                        $worker["SALARY"],
                        $worker["PICTURE"],
                        $worker["RATING"]
                    ));
                }
                $this->setWorkers($workers);
                echo "<pre>";
                print_r($this->getWorkers());
                echo "</pre>";
                
            } catch (PDOException | Exception $th) {
                echo "La conexion no ha funcionado".$th->getMessage();
            }
        }

        function getNombre(){
            try {
                $sql="SELECT * FROM worker WHERE name=?";
                $stmt=$this->conn->prepare("$sql");
                $stmt->bindParam(1,$this->name, PDO::PARAM_STR);
                $stmt->execute();
                return $stmt;
            } catch (PDOException | Exception $th) {
                echo "La conexion no ha funcionado".$th->getMessage();
            }
        }

        function drawWorkersList(){
            $this->getAll();
            $workers = $this->getWorkers();
            //print_r($workers);exit;
            $output="";
            foreach($workers as $worker){
                $output.= "<tr scope='row'>";
                $output.= "<td>";
                $output.= "<img src='img/photo/hop1.jpg' width='50'> </td>";
                $output.= "</td>";
                $output.="<td>".$worker->getName()."</td>";
                $output.="<td>";
                $output.="Frontend";
                $output.="<small class='d-block'>".substr($worker->getAbout(),0,50)."....</small>";
                $output .= "    </td>";
                $output .= "    <td>";
                $output .= "        <div class='rating_container'>";
                $output .="width='10'></a><a href='ratingUpdate.php?id=1&rating=2'><img src='img/star_up.png'
                width='10'></a><a href='ratingUpdate.php?id=1&rating=3'><img src='img/star_up.png'
                width='10'></a><a href='ratingUpdate.php?id=1&rating=4'><img src='img/star_down.png'
                width='10'></a><a href='ratingUpdate.php?id=1&rating=5'><img src='img/star_down.png'
                width='10'></a> </div> </td>";
                $output.="<td><a href='card.php?id=".$worker->getId()."' class='more'>+Info</a></td>
                </tr>";
            }
            return $output;             
        }
    }

    $n=new Todo;
/*     $n->connect(); */
    $n->getAll();
    
?>