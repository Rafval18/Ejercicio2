<?php

class Worker extends Todo{
    private $id;
    private $name;
    private $email;
    private $country;
    private $about;
    private $salary;
    private $picture;
    private $rating;

    function __construct($id,$name,$email,$country,$about,$salary,$picture,$rating){
        $id=$this->id;
        $name=$this->name;
        $email=$this->email;
        $country=$this->country;
        $about=$this->about;
        $salary=$this->salary;
        $picture=$this->picture;
        $rating=$this->rating;
    }

    

    /**
     * Get the value of id
     */ 
    public function getId()
    {
        return $this->id;
    }

    /**
     * Get the value of name
     */ 
    public function getName()
    {
        return $this->name;
    }

    /**
     * Get the value of email
     */ 
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Get the value of country
     */ 
    public function getCountry()
    {
        return $this->country;
    }

    /**
     * Get the value of about
     */ 
    public function getAbout()
    {
        return $this->about;
    }

    /**
     * Get the value of salary
     */ 
    public function getSalary()
    {
        return $this->salary;
    }

    /**
     * Get the value of picture
     */ 
    public function getPicture()
    {
        return $this->picture;
    }

    /**
     * Get the value of rating
     */ 
    public function getRating()
    {
        return $this->rating;
    }
}


    
    
    