<?php

require_once "autoload.php";

$cartera = new Cartera();
$cartera->import("data.csv");

?>